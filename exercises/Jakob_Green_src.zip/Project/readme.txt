-- Setup application --
To run the application, simply follow the steps to run any of the exercises from this semester