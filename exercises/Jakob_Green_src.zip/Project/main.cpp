#include "FireApplication.h"

int main()
{
    FireApplication app;
    return app.Run();
}
